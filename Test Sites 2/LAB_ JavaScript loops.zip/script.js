
function drawTriangle(size) {
let i;
let j;
let result = "";

for (i = 1; i < size+1; i++) {
    for (j = 1; j < i+1; j++) {
        result += "*";
    }
        if (i !== size) {
            result += "\n";
        }
            }
            console.log(result);
}
    
