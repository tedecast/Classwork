function divideArray(numbers) {
    let evenNums = [];
    let oddNums = [];
    for (let numb of numbers) {
        if (numb % 2 === 0) {
            evenNums.push(numb);
        } else {
            oddNums.push(numb);
        }
    }

    evenNums.sort(sortFunction);
    oddNums.sort(sortFunction);
    console.log("Even numbers:");

    if (evenNums.length === 0) {
        console.log("None");
    } else {
        for (let evenNum of evenNums) {
            console.log(evenNum);
        } 
    }
    
    console.log("Odd numbers:");
    if (oddNums.length === 0) {
        console.log("None");
    } else {
        for (let oddNum of oddNums) {
            console.log(oddNum);
        }
    } 
}

function sortFunction(numb1, numb2) {
    return numb1 - numb2; 
}