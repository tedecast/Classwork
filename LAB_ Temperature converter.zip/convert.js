window.addEventListener("DOMContentLoaded", domLoaded);

function domLoaded() {
   // TODO: Complete the function
   document.querySelector("#convertButton").onclick = domLoaded;
}

function convertCtoF(degreesCelsius) {
   // TODO: Complete the function
   let cTemp = celsius;
   let cToFahr = cTemp * 9 / 5 + 32;
   let message = cTemp+'\xB0C is ' + cToFahr + ' \xB0F.';
   console.log(message);
}

function convertFtoC(degreesFahrenheit) {
   // TODO: Complete the function
   let fTemp = fahrenheit;
   let fToCel = (fTemp - 32) * 5 / 9;
   let message = fTemp+'\xB0F is ' + fToCel + '\xB0C.';
   console.log(message);
   

}
